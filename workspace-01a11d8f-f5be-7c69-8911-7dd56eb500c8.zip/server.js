// server.js - Full-Featured Real-Time WebSocket & Static Game Server for SNIPER DUELS
const http = require('http');
const fs = require('fs');
const path = require('path');

let WebSocketServer = null;
try {
  WebSocketServer = require('ws').WebSocketServer;
} catch (e) {
  console.info('[Server] Optional "ws" module not present. Running resilient pure Node.js HTTP server.');
}

const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.mjs': 'text/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.glb': 'model/gltf-binary',
  '.gltf': 'model/gltf+json'
};

// 1. Static HTTP Request Handler
function requestHandler(req, res) {
  let reqPath = req.url.split('?')[0];
  if (reqPath === '/') reqPath = '/index.html';

  const filePath = path.join(__dirname, reqPath);
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end(`500 Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, {
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Cache-Control': 'no-cache, no-store, must-revalidate'
      });
      res.end(content, 'utf-8');
    }
  });
}

// 2. HTTP Server instances (binds port 3000 as primary preview port, and port 8000 as secondary)
const server = http.createServer(requestHandler);
const server8000 = http.createServer(requestHandler);

// 3. Real-Time 60Hz Authoritative WebSocket Game Server
let wss = null;
let wss8000 = null;

let clients = new Map();
let nextPlayerId = 1;

let matchState = {
  status: 'LOBBY',
  scoreBlue: 0,
  scoreRed: 0,
  round: 1,
  map: 'blockout'
};

if (WebSocketServer) {
  wss = new WebSocketServer({ server });
  wss8000 = new WebSocketServer({ server: server8000 });
  wss.on('connection', handleConnection);
  wss8000.on('connection', handleConnection);
}

function handleConnection(ws) {
  const playerId = `player_${nextPlayerId++}`;
  const team = clients.size % 2 === 0 ? 'BLUE' : 'RED';

  const playerObj = {
    id: playerId,
    team: team,
    ws: ws,
    health: 100,
    position: { x: 0, y: 1.8, z: -100 },
    rotation: { y: 0, pitch: 0 },
    slot: 'SNIPER',
    isAiming: false,
    isSliding: false
  };

  clients.set(playerId, playerObj);
  console.log(`[WS] ${playerId} connected on team ${team}. Total players: ${clients.size}`);

  ws.send(JSON.stringify({
    type: 'INIT',
    playerId: playerId,
    team: team,
    matchState: matchState,
    playerCount: clients.size
  }));

  broadcastExcept(playerId, {
    type: 'PLAYER_JOINED',
    player: {
      id: playerId,
      team: team,
      position: playerObj.position,
      rotation: playerObj.rotation
    }
  });

  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      handleClientMessage(playerId, data);
    } catch (e) {
      console.warn(`[WS] Invalid message from ${playerId}:`, e.message);
    }
  });

  ws.on('close', () => {
    console.log(`[WS] ${playerId} disconnected.`);
    clients.delete(playerId);
    broadcast({
      type: 'PLAYER_LEFT',
      playerId: playerId
    });
  });
}

if (wss && wss8000) {
  wss.on('connection', handleConnection);
  wss8000.on('connection', handleConnection);
}

function handleClientMessage(senderId, data) {
  const player = clients.get(senderId);
  if (!player) return;

  switch (data.type) {
    case 'SYNC_TRANSFORM':
      player.position = data.position;
      player.rotation = data.rotation;
      player.slot = data.slot;
      player.isAiming = data.isAiming;
      player.isSliding = data.isSliding;

      broadcastExcept(senderId, {
        type: 'PLAYER_TRANSFORM',
        id: senderId,
        position: data.position,
        rotation: data.rotation,
        slot: data.slot,
        isAiming: data.isAiming,
        isSliding: data.isSliding
      });
      break;

    case 'FIRE_WEAPON':
      broadcastExcept(senderId, {
        type: 'REMOTE_FIRE',
        id: senderId,
        origin: data.origin,
        direction: data.direction,
        spread: data.spread,
        isAiming: data.isAiming,
        weaponType: data.weaponType
      });
      break;

    case 'INFLICT_DAMAGE':
      const target = clients.get(data.targetId);
      if (target) {
        target.health = Math.max(0, target.health - data.damage);
        broadcast({
          type: 'DAMAGE_EVENT',
          targetId: data.targetId,
          attackerId: senderId,
          damage: data.damage,
          isHeadshot: data.isHeadshot,
          remainingHealth: target.health
        });

        if (target.health <= 0) {
          if (player.team === 'BLUE') matchState.scoreBlue++;
          else matchState.scoreRed++;

          broadcast({
            type: 'ROUND_WINNER',
            winnerTeam: player.team,
            killerId: senderId,
            victimId: data.targetId,
            isHeadshot: data.isHeadshot,
            scores: { blue: matchState.scoreBlue, red: matchState.scoreRed }
          });
        }
      }
      break;

    case 'CHANGE_MAP':
      matchState.map = data.mapName;
      broadcast({ type: 'MAP_UPDATED', mapName: data.mapName });
      break;
  }
}

function broadcast(msg) {
  const payload = JSON.stringify(msg);
  for (const client of clients.values()) {
    if (client.ws.readyState === client.ws.OPEN) {
      client.ws.send(payload);
    }
  }
}

function broadcastExcept(excludeId, msg) {
  const payload = JSON.stringify(msg);
  for (const [id, client] of clients.entries()) {
    if (id !== excludeId && client.ws.readyState === client.ws.OPEN) {
      client.ws.send(payload);
    }
  }
}

server.listen(3000, '0.0.0.0', () => {
  console.log(`SNIPER DUELS Primary Server live on http://0.0.0.0:3000`);
});

server8000.listen(8000, '0.0.0.0', () => {
  console.log(`SNIPER DUELS Secondary Server live on http://0.0.0.0:8000`);
});
