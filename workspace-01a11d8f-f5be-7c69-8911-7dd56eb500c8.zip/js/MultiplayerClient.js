// MultiplayerClient.js - Real-Time 60Hz WebSocket Network Sync Client
import * as THREE from 'three';

export class MultiplayerClient {
  constructor(gameEngine) {
    this.game = gameEngine;
    this.ws = null;
    this.isConnected = false;
    this.localPlayerId = null;
    this.localTeam = 'BLUE';
    this.remotePlayers = new Map();

    this.syncInterval = null;
    this.connect();
  }

  connect() {
    if (!location.host || location.protocol === 'file:' || location.origin === 'null') {
      console.info('[MultiplayerClient] Standalone/Offline mode active.');
      return;
    }
    try {
      const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${location.host}`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnected = true;
        console.log('[MultiplayerClient] Connected to WebSocket Game Server!');
        this.startTransformSync();
        this.updateHUDOnlineStatus(true);
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          this.handleServerMessage(msg);
        } catch (e) {
          console.warn('[MultiplayerClient] Bad message:', e);
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        this.updateHUDOnlineStatus(false);
        if (this.syncInterval) clearInterval(this.syncInterval);
      };

      this.ws.onerror = () => {
        this.isConnected = false;
        this.updateHUDOnlineStatus(false);
      };
    } catch (err) {
      console.info('[MultiplayerClient] Running in Solo Offline / Local Bot mode.');
    }
  }

  updateHUDOnlineStatus(online) {
    const banner = document.getElementById('match-status-banner');
    if (online) {
      console.log('[Multiplayer] Real-time multiplayer synchronization active.');
    }
  }

  startTransformSync() {
    // 60Hz state sync
    this.syncInterval = setInterval(() => {
      if (!this.isConnected || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;

      const pos = this.game.controls.getPosition();
      const payload = {
        type: 'SYNC_TRANSFORM',
        position: { x: pos.x, y: pos.y, z: pos.z },
        rotation: { y: this.game.controls.yaw, pitch: this.game.controls.pitch },
        slot: this.game.weaponSystem.currentSlot,
        isAiming: this.game.weaponSystem.isAiming,
        isSliding: this.game.controls.isSliding
      };

      this.ws.send(JSON.stringify(payload));
    }, 1000 / 60);
  }

  sendFireWeapon(origin, direction, spread, isAiming, weaponType) {
    if (!this.isConnected || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({
      type: 'FIRE_WEAPON',
      origin: { x: origin.x, y: origin.y, z: origin.z },
      direction: { x: direction.x, y: direction.y, z: direction.z },
      spread: spread,
      isAiming: isAiming,
      weaponType: weaponType
    }));
  }

  sendInflictDamage(targetId, damage, isHeadshot) {
    if (!this.isConnected || this.ws.readyState !== WebSocket.OPEN) return;
    this.ws.send(JSON.stringify({
      type: 'INFLICT_DAMAGE',
      targetId: targetId,
      damage: damage,
      isHeadshot: isHeadshot
    }));
  }

  handleServerMessage(msg) {
    switch (msg.type) {
      case 'INIT':
        this.localPlayerId = msg.playerId;
        this.localTeam = msg.team;
        break;

      case 'PLAYER_TRANSFORM':
        // If there's a remote human player, mirror them in place of the Bot!
        if (this.game.bot && this.game.bot.mesh) {
          const p = msg.position;
          this.game.bot.position.set(p.x, p.y, p.z);
          this.game.bot.mesh.position.set(p.x, p.y, p.z);
          this.game.bot.mesh.rotation.y = msg.rotation.y;
        }
        break;

      case 'REMOTE_FIRE':
        // Render remote player tracer and gunshot audio
        this.game.audio.playSniperShot();
        const start = new THREE.Vector3(msg.origin.x, msg.origin.y, msg.origin.z);
        const dir = new THREE.Vector3(msg.direction.x, msg.direction.y, msg.direction.z);
        const end = start.clone().addScaledVector(dir, 150);
        this.game.particles.addTracer(start, end);
        break;

      case 'ROUND_WINNER':
        this.game.matchManager.endRound(msg.winnerTeam);
        break;
    }
  }
}
