// CameraManager.js - Dual-Pass Rendering, No-Clip Viewmodel & ADS Scope Zoom
import * as THREE from 'three';

export class CameraManager {
  constructor(renderer, aspect) {
    this.renderer = renderer;

    const safeAspect = (aspect && !isNaN(aspect) && isFinite(aspect) && aspect > 0) ? aspect : (16 / 9);

    // 1. World Camera
    this.baseFov = 75;
    this.scopedFov = 20;
    this.worldCamera = new THREE.PerspectiveCamera(this.baseFov, safeAspect, 0.1, 1000);

    // 2. Dedicated Viewmodel Camera (Fixed FOV prevents fisheye distortion)
    this.vmFov = 52;
    this.vmCamera = new THREE.PerspectiveCamera(this.vmFov, safeAspect, 0.01, 20);

    // Viewmodel scene
    this.vmScene = new THREE.Scene();

    // Lighting for Viewmodel so weapons always look vibrant and distinct
    const vmAmbient = new THREE.AmbientLight(0xffffff, 0.8);
    this.vmScene.add(vmAmbient);
    const vmDirectional = new THREE.DirectionalLight(0xffffff, 0.9);
    vmDirectional.position.set(2, 4, 3);
    this.vmScene.add(vmDirectional);
    const vmRimLight = new THREE.DirectionalLight(0x00c3ff, 0.4);
    vmRimLight.position.set(-2, -1, -2);
    this.vmScene.add(vmRimLight);

    // Scope Overlay DOM Element
    this.scopeOverlay = document.getElementById('sniper-scope-overlay');
  }

  onResize(width, height) {
    const w = (width && width > 0) ? width : (window.innerWidth || 800);
    const h = (height && height > 0) ? height : (window.innerHeight || 600);
    const aspect = w / h;

    this.worldCamera.aspect = aspect;
    this.worldCamera.updateProjectionMatrix();

    this.vmCamera.aspect = aspect;
    this.vmCamera.updateProjectionMatrix();

    this.renderer.setSize(w, h);
  }

  updateADS(adsProgress, delta) {
    // Interpolate World Camera FOV for high magnification zoom
    const targetFov = THREE.MathUtils.lerp(this.baseFov, this.scopedFov, adsProgress);
    this.worldCamera.fov = targetFov;
    this.worldCamera.updateProjectionMatrix();

    // Update Scope DOM Overlay opacity
    if (this.scopeOverlay) {
      if (adsProgress > 0.6) {
        this.scopeOverlay.style.opacity = ((adsProgress - 0.6) / 0.4).toFixed(3);
        this.scopeOverlay.style.pointerEvents = 'none';
        this.scopeOverlay.style.display = 'block';
      } else {
        this.scopeOverlay.style.opacity = '0';
        this.scopeOverlay.style.display = 'none';
      }
    }
  }

  // Dual-Pass Render
  render(worldScene) {
    // Ensure world scene matrix is up to date
    this.worldCamera.updateMatrixWorld(true);

    // Render World
    this.renderer.autoClear = false;
    this.renderer.clear();
    this.renderer.render(worldScene, this.worldCamera);

    // Sync Viewmodel camera with World camera transform
    this.vmCamera.position.set(0, 0, 0);
    this.vmCamera.quaternion.copy(this.worldCamera.getWorldQuaternion(new THREE.Quaternion()));
    this.vmCamera.updateMatrixWorld(true);

    // Clear Depth Buffer so viewmodel renders cleanly on top without wall clipping
    this.renderer.clearDepth();

    // Render Viewmodel Weapon
    this.renderer.render(this.vmScene, this.vmCamera);
  }
}
