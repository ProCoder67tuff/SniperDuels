// MatchManager.js - State Machine, Matchmaking Duel Pads, Round Engine, "First to 6 Wins"
import * as THREE from 'three';

export class MatchManager {
  constructor(controls, bot, map, audio, particles, caseSystem) {
    this.controls = controls;
    this.bot = bot;
    this.map = map;
    this.audio = audio;
    this.particles = particles;
    this.caseSystem = caseSystem;

    // Match Rules: "First to 6 Wins"
    this.maxScore = 6;
    this.scorePlayer = 0;
    this.scoreBot = 0;
    this.roundNumber = 1;

    // States: 'LOBBY', 'COUNTDOWN', 'TELEPORT', 'WARMUP', 'ROUND_ACTIVE', 'ROUND_END', 'MATCH_VICTORY'
    this.state = 'LOBBY';
    this.stateTimer = 0;
    this.roundTimeRemaining = 60;

    // Player Combat State
    this.playerHealth = 100;
    this.playerMaxHealth = 100;
    this.isPlayerAlive = true;

    // Pad detection
    this.activePad = null;
    this.padCountdown = 3.0;

    this.initUI();
  }

  initUI() {
    this.updateHUDScore();
    this.updateHUDHealth();
    this.updateStateBanner('LOBBY PRACTICE - STEP ON A DUEL PAD TO PLAY', false);
  }

  updateHUDScore() {
    const elPlayer = document.getElementById('score-blue');
    const elBot = document.getElementById('score-red');
    if (elPlayer) elPlayer.textContent = this.scorePlayer;
    if (elBot) elBot.textContent = this.scoreBot;

    // Score pips (first to 6)
    const pipsBlue = document.getElementById('pips-blue');
    const pipsRed = document.getElementById('pips-red');
    if (pipsBlue && pipsRed) {
      pipsBlue.innerHTML = '';
      pipsRed.innerHTML = '';
      for (let i = 0; i < this.maxScore; i++) {
        const bPip = document.createElement('div');
        bPip.className = `score-pip ${i < this.scorePlayer ? 'active' : ''}`;
        pipsBlue.appendChild(bPip);

        const rPip = document.createElement('div');
        rPip.className = `score-pip ${i < this.scoreBot ? 'active red' : ''}`;
        pipsRed.appendChild(rPip);
      }
    }
  }

  updateHUDHealth() {
    const bar = document.getElementById('health-bar-fill');
    const text = document.getElementById('health-text');
    if (bar) bar.style.width = `${Math.max(0, this.playerHealth)}%`;
    if (text) text.textContent = `${Math.max(0, this.playerHealth)} HP`;
  }

  updateStateBanner(text, visible = true, color = '#ffffff') {
    const banner = document.getElementById('match-status-banner');
    if (banner) {
      banner.style.display = visible ? 'block' : 'none';
      banner.textContent = text;
      banner.style.color = color;
    }
  }

  // Check if player stepped on any Duel Pad in lobby
  checkDuelPads(playerPosition) {
    if (this.state !== 'LOBBY') return;

    let onAnyPad = false;
    for (const pad of this.map.duelPads) {
      const padPos = pad.position;
      const dist = Math.hypot(playerPosition.x - padPos.x, playerPosition.z - padPos.z);

      if (dist < pad.userData.radius) {
        onAnyPad = true;
        if (this.activePad !== pad) {
          this.activePad = pad;
          this.padCountdown = 3.0;
          this.bot.setDifficulty(pad.userData.mode);
        }
        break;
      }
    }

    if (onAnyPad) {
      this.padCountdown -= 0.016;
      const sec = Math.ceil(this.padCountdown);
      this.updateStateBanner(`MATCH STARTING IN ${sec}... (${this.activePad.userData.label})`, true, '#00ffcc');
      if (this.padCountdown <= 0) {
        this.startMatch();
      }
    } else {
      if (this.activePad) {
        this.activePad = null;
        this.updateStateBanner('LOBBY PRACTICE - STEP ON A DUEL PAD TO PLAY', true, '#ffffff');
      }
    }
  }

  startMatch() {
    this.scorePlayer = 0;
    this.scoreBot = 0;
    this.roundNumber = 1;
    this.updateHUDScore();
    this.setupRound();
  }

  setupRound() {
    this.state = 'WARMUP';
    this.stateTimer = 3.0;
    this.roundTimeRemaining = 60;
    this.playerHealth = 100;
    this.isPlayerAlive = true;
    this.updateHUDHealth();

    // Teleport Player to Blue Spawn, facing North (Orange side)
    this.controls.teleport(this.map.spawnBlue, new THREE.Vector3(0, 1.8, 0));

    // Teleport & reset Bot to Orange Spawn
    this.bot.reset(this.map.spawnOrange);

    // Raise spawn barrier forcefields
    this.map.blueBarrier.visible = true;
    this.map.orangeBarrier.visible = true;

    this.audio.playCountdownTick();
    this.updateStateBanner(`ROUND ${this.roundNumber} - WARMUP (3)`, true, '#00d2ff');
  }

  startRoundActive() {
    this.state = 'ROUND_ACTIVE';
    this.map.blueBarrier.visible = false;
    this.map.orangeBarrier.visible = false;
    this.audio.stopLobbyMusic();
    this.audio.playRoundStart();
    this.updateStateBanner('ROUND ACTIVE - ELIMINATE THE ENEMY!', true, '#00ffcc');

    setTimeout(() => {
      if (this.state === 'ROUND_ACTIVE') {
        this.updateStateBanner('', false);
      }
    }, 1500);
  }

  // When player inflicts damage on Bot
  onBotDamaged(damage, isHeadshot) {
    if (this.state !== 'ROUND_ACTIVE') return;

    this.audio.playHitmarker(isHeadshot);
    this.showHitmarker(isHeadshot);
    this.showDamageNumber(damage, isHeadshot);

    const isFatal = this.bot.takeDamage(damage, isHeadshot);
    if (isFatal) {
      this.onBotKilled(isHeadshot);
    }
  }

  onBotKilled(isHeadshot) {
    this.addKillFeedEntry('YOU', 'BOT_ALPHA', isHeadshot);

    // Economy coin rewards
    const reward = isHeadshot ? 75 : 50;
    this.caseSystem.addCoins(reward);

    this.scorePlayer++;
    this.updateHUDScore();
    this.audio.playRoundWon();

    if (this.scorePlayer >= this.maxScore) {
      this.triggerMatchVictory('BLUE');
    } else {
      this.endRound('BLUE');
    }
  }

  // When Bot shoots player
  onPlayerDamaged(damage, isHeadshot) {
    if (this.state !== 'ROUND_ACTIVE' || !this.isPlayerAlive) return;

    this.playerHealth -= damage;
    this.updateHUDHealth();
    this.showDamageVignette();

    if (this.playerHealth <= 0) {
      this.isPlayerAlive = false;
      this.playerHealth = 0;
      this.updateHUDHealth();
      this.onPlayerKilled(isHeadshot);
    }
  }

  onPlayerKilled(isHeadshot) {
    this.addKillFeedEntry('BOT_ALPHA', 'YOU', isHeadshot);
    this.scoreBot++;
    this.updateHUDScore();
    this.audio.playRoundLost();

    if (this.scoreBot >= this.maxScore) {
      this.triggerMatchVictory('RED');
    } else {
      this.endRound('RED');
    }
  }

  endRound(winner) {
    this.state = 'ROUND_END';
    this.stateTimer = 3.5;
    const bannerColor = winner === 'BLUE' ? '#00d2ff' : '#ff4444';
    this.updateStateBanner(`${winner} WINS ROUND ${this.roundNumber}!`, true, bannerColor);
  }

  triggerMatchVictory(winner) {
    this.state = 'MATCH_VICTORY';
    this.stateTimer = 6.0;

    if (winner === 'BLUE') {
      this.updateStateBanner('VICTORY! FIRST TO 6 WINS (+500 COINS)', true, '#f1c40f');
      this.caseSystem.addCoins(500);
      this.audio.playUnlockFanfare('legendary');
      this.particles.spawnVictoryConfetti(this.controls.getPosition());
    } else {
      this.updateStateBanner('DEFEAT! RED REACHED 6 WINS', true, '#ff4444');
      this.audio.playRoundLost();
    }
  }

  returnToLobby() {
    this.state = 'LOBBY';
    this.controls.teleport(this.map.lobbySpawn, new THREE.Vector3(0, 1.8, -120));
    this.updateStateBanner('LOBBY PRACTICE - STEP ON A DUEL PAD TO PLAY', true, '#ffffff');
    this.scorePlayer = 0;
    this.scoreBot = 0;
    this.updateHUDScore();
    this.audio.startLobbyMusic();
  }

  // UI Effects
  showHitmarker(isHeadshot) {
    const hm = document.getElementById('hitmarker');
    if (!hm) return;
    hm.className = `hitmarker-active ${isHeadshot ? 'headshot' : ''}`;
    setTimeout(() => {
      hm.className = '';
    }, 180);
  }

  showDamageNumber(val, isHeadshot) {
    const el = document.createElement('div');
    el.className = `floating-dmg ${isHeadshot ? 'crit' : ''}`;
    el.textContent = isHeadshot ? `${val} CRIT!` : `${val}`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 700);
  }

  showDamageVignette() {
    const vig = document.getElementById('damage-vignette');
    if (!vig) return;
    vig.style.opacity = '1.0';
    setTimeout(() => {
      vig.style.opacity = '0.0';
    }, 300);
  }

  addKillFeedEntry(killer, victim, isHeadshot) {
    const feed = document.getElementById('kill-feed');
    if (!feed) return;
    const entry = document.createElement('div');
    entry.className = 'kill-feed-entry';
    entry.innerHTML = `
      <span class="killer">${killer}</span>
      <span class="weapon-icon">${isHeadshot ? '🎯 [AWP HEADSHOT]' : '💥 [AWP]'}</span>
      <span class="victim">${victim}</span>
    `;
    feed.appendChild(entry);
    setTimeout(() => {
      entry.style.opacity = '0';
      setTimeout(() => entry.remove(), 500);
    }, 4000);
  }

  update(delta) {
    const playerPos = this.controls.getPosition();

    // Check Duel pads in Lobby
    if (this.state === 'LOBBY') {
      this.checkDuelPads(playerPos);
    }

    // Warmup countdown
    if (this.state === 'WARMUP') {
      this.stateTimer -= delta;
      const count = Math.ceil(this.stateTimer);
      this.updateStateBanner(`ROUND ${this.roundNumber} - STARTING IN ${count}...`, true, '#00d2ff');
      if (this.stateTimer <= 0) {
        this.startRoundActive();
      }
    }

    // Active round timer
    if (this.state === 'ROUND_ACTIVE') {
      this.roundTimeRemaining -= delta;
      const timerEl = document.getElementById('round-timer');
      if (timerEl) {
        timerEl.textContent = `0:${Math.max(0, Math.ceil(this.roundTimeRemaining)).toString().padStart(2, '0')}`;
      }

      // Round timeout (Draw or Bot win)
      if (this.roundTimeRemaining <= 0) {
        this.endRound('RED');
      }

      // Update AI bot
      this.bot.update(delta, playerPos, this.state, (dmg, isHead) => {
        this.onPlayerDamaged(dmg, isHead);
      });
    }

    // Round End delay
    if (this.state === 'ROUND_END') {
      this.stateTimer -= delta;
      if (this.stateTimer <= 0) {
        this.roundNumber++;
        this.setupRound();
      }
    }

    // Match Victory delay -> return to lobby
    if (this.state === 'MATCH_VICTORY') {
      this.stateTimer -= delta;
      if (this.stateTimer <= 0) {
        this.returnToLobby();
      }
    }
  }
}
